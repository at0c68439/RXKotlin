package com.example.at0c68439.rxjavawithkotlin.di

import android.content.pm.ComponentInfo
import com.example.at0c68439.rxjavawithkotlin.Activities.HomeActivity
import dagger.Component
import javax.inject.Singleton


@Singleton
@Component(modules = arrayOf(MyModule::class, ViewModelModule::class))
interface IMyComponent  {

    fun inject(homeActivity: HomeActivity)
}