package com.example.at0c68439.rxjavawithkotlin.Activities

import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import com.example.at0c68439.rxjavawithkotlin.MainApplication
import com.example.at0c68439.rxjavawithkotlin.R
import com.example.at0c68439.rxjavawithkotlin.ViewModel.HomeViewModel
import com.example.at0c68439.rxjavawithkotlin.databinding.ActivityHomeBinding
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : BaseActivity<HomeViewModel>() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        setSupportActionBar(activity_settings_toolbar)

    }

    override fun resolveComponent() {

        val mainApplication = application as MainApplication
        mainApplication.myBswComponent.inject(this)

    }

    override fun resolveViewModel() {
        viewModel = ViewModelProviders
                .of(this, _viewModelFactory)
                .get(HomeViewModel::class.java)

    }

    override fun bindViewModel(viewModel: HomeViewModel) {

        val binding = DataBindingUtil.setContentView<ActivityHomeBinding>(this, R.layout.activity_home)
        binding.homeViewModel = viewModel

    }

}
