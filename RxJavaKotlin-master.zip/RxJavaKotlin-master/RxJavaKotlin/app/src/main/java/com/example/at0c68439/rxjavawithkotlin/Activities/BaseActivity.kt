package com.example.at0c68439.rxjavawithkotlin.Activities

import android.arch.lifecycle.LifecycleRegistry
import android.arch.lifecycle.LifecycleRegistryOwner
import android.arch.lifecycle.ViewModelProvider
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.at0c68439.rxjavawithkotlin.ViewModel.BaseViewModel

import javax.inject.Inject

abstract class BaseActivity<T : BaseViewModel> : AppCompatActivity(), LifecycleRegistryOwner {


    private val lifecycleRegistry: LifecycleRegistry = LifecycleRegistry(this)

    @Inject
    lateinit var _viewModelFactory: ViewModelProvider.Factory

    lateinit var viewModel: T
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        resolveComponent()
        resolveViewModel()
        bindViewModel(viewModel)
    }
    override fun getLifecycle(): LifecycleRegistry {

        return lifecycleRegistry

    }

    abstract fun resolveComponent()
    abstract fun resolveViewModel()
    abstract fun bindViewModel(viewModel: T)
}
