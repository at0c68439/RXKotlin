package com.example.at0c68439.rxjavawithkotlin.ViewModel

import android.arch.lifecycle.ViewModel

abstract  class BaseViewModel : ViewModel() {
}