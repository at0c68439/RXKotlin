package com.example.at0c68439.rxjavawithkotlin.di

import dagger.Module

@Module(includes = arrayOf(ViewModelModule::class))
class MyModule {
}