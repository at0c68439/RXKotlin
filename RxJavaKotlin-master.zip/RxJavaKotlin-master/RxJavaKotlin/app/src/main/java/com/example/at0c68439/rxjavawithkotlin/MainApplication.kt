package com.example.at0c68439.rxjavawithkotlin

import android.app.Activity
import android.app.Application
import android.os.Bundle
import com.example.at0c68439.rxjavawithkotlin.di.DaggerIMyComponent
import com.example.at0c68439.rxjavawithkotlin.di.IMyComponent
import com.github.ajalt.timberkt.d


class MainApplication : Application(), Application.ActivityLifecycleCallbacks {

    private lateinit var _myBswComponent: IMyComponent
    val myBswComponent: IMyComponent
        get() = _myBswComponent

    override fun onCreate() {
        super.onCreate()

        _myBswComponent = DaggerIMyComponent.builder().build()

    }

    override fun onActivityCreated(activity: Activity?, p1: Bundle?) {

        d { "${activity?.localClassName} onActivityCreated" }
        currentActivity = activity
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onActivityStopped(p0: Activity?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onActivitySaveInstanceState(p0: Activity?, p1: Bundle?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onActivityDestroyed(p0: Activity?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onActivityStarted(p0: Activity?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onActivityResumed(activity: Activity?) {

        d { "${activity?.localClassName} onActivityResumed" }
        currentActivity = activity    }

    override fun onActivityPaused(p0: Activity?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    companion object {
        var currentActivity: Activity? = null
    }
}