package com.example.at0c68439.rxjavawithkotlin.ViewModel

import android.databinding.ObservableBoolean
import com.example.at0c68439.rxjavawithkotlin.MainApplication
import javax.inject.Inject


class HomeViewModel : BaseViewModel {

    @Inject
    constructor( ) : super()

    init {

        val applicationContext = MainApplication.currentActivity!!.applicationContext
    }

    val useFingerprintToSignIn = ObservableBoolean(true)
    val isPharmacyPrescriptionNotificationEnabled = ObservableBoolean(true)
    val isProxyPharmacyPrescriptionNotificationEnabled = ObservableBoolean(true)


}